import React from 'react';
import './index.css';
import Calculator from './components/Calculator';

const App = () => {
  return (
    <div className="App">
      <Calculator />
    </div>
  );
};

export default App;
